// Seeded Initial Data (3 sample records as required by brief)
const defaultCertificates = [
  {
    id: "TOOP-2026-APPR-0001",
    recipient: "Eleanor Vance",
    type: "Appreciation",
    event: "Borderless Poetics Workshop 2026",
    role: "Featured Literary Artist",
    date: "2026-02-15",
    status: "Active"
  },
  {
    id: "TOOP-2025-ACHV-0002",
    recipient: "Liam Vance",
    type: "Achievement",
    event: "Transfrontier Prose Competition 2025",
    role: "First Place Winner",
    date: "2025-11-20",
    status: "Active"
  },
  {
    id: "TOOP-2026-PART-0003",
    recipient: "Marcus Dupont",
    type: "Participation",
    event: "Cross-Border Poetry Slam 2026",
    role: "Youth Participant",
    date: "2026-01-10",
    status: "Revoked"
  }
];

// State Management
let certificates = [];
let currentAdminView = 'login-view'; // Default subview under admin tab

// Helper to extract a clean 4-digit year from any date string
function getYearFromDate(dateVal) {
  if (!dateVal) return new Date().getFullYear().toString();
  // Match any 4 digit year block in the string (e.g. 2026)
  const match = dateVal.match(/\b\d{4}\b/);
  if (match) return match[0];
  
  // If no 4-digit block, split by dash or slash and check parts
  const parts = dateVal.split(/[-/]/);
  for (let part of parts) {
    if (part.length === 4 && !isNaN(part)) return part;
  }
  
  // Fallback to Date parsing if possible
  try {
    const d = new Date(dateVal);
    if (!isNaN(d.getTime())) {
      return d.getFullYear().toString();
    }
  } catch (e) {}
  
  // Final fallback to current year
  return new Date().getFullYear().toString();
}

// Helper to safely render icons if Lucide is available
function safeCreateIcons() {
  try {
    if (typeof lucide !== 'undefined' && lucide.createIcons) {
      lucide.createIcons();
    }
  } catch (e) {
    console.warn("Lucide icons failed to load or render", e);
  }
}

// Global Auth State and SessionStorage Safe Wrappers
let isAdminAuthenticated = false;

function setAdminAuthenticated(val) {
  isAdminAuthenticated = val;
  try {
    sessionStorage.setItem("admin_authenticated", val ? "true" : "false");
  } catch (e) {
    console.warn("sessionStorage is not accessible", e);
  }
}

function checkAdminAuthenticated() {
  if (isAdminAuthenticated) return true;
  try {
    return sessionStorage.getItem("admin_authenticated") === "true";
  } catch (e) {
    return false;
  }
}

function logoutAdmin() {
  isAdminAuthenticated = false;
  try {
    sessionStorage.removeItem("admin_authenticated");
  } catch (e) {
    console.warn("sessionStorage is not accessible", e);
  }
}

// Initialize Application
document.addEventListener("DOMContentLoaded", () => {
  initData();
  setupRouting();
  setupFormBindings();
  setupVerificationPortal();
  setupCSVTools();
  setupAdminPortal();
  setupBulkTextAreaImport();
  checkUrlParams();
  
  // Render Lucide Icons
  safeCreateIcons();
});

// Load data from localStorage or seed defaults
function initData() {
  const stored = localStorage.getItem("toop_certificates");
  if (stored) {
    try {
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed)) {
        // Self-heal: filter out invalid entries to prevent database crash
        certificates = parsed.filter(c => c && typeof c === 'object' && c.id && c.recipient);
        if (certificates.length === 0) {
          certificates = [...defaultCertificates];
          saveData();
        }
      } else {
        certificates = [...defaultCertificates];
        saveData();
      }
    } catch (e) {
      console.error("Error parsing stored certificates, reloading defaults", e);
      certificates = [...defaultCertificates];
      saveData();
    }
  } else {
    certificates = [...defaultCertificates];
    saveData();
  }
}

// Sync current certificates array to localStorage
function saveData() {
  localStorage.setItem("toop_certificates", JSON.stringify(certificates));
}

// Simple Router (Tab view-switching)
function setupRouting() {
  const tabs = document.querySelectorAll(".nav-tab");
  const views = document.querySelectorAll(".view-section");
  const logoLink = document.getElementById("nav-logo-link");

  tabs.forEach(tab => {
    tab.addEventListener("click", () => {
      const target = tab.getAttribute("data-target");
      switchTab(target);
    });
  });

  logoLink.addEventListener("click", (e) => {
    e.preventDefault();
    switchTab("verify-view");
  });
}

function switchTab(targetViewId) {
  const tabs = document.querySelectorAll(".nav-tab");
  const views = document.querySelectorAll(".view-section");

  // Manage active class on tabs
  tabs.forEach(t => {
    if (t.getAttribute("data-target") === targetViewId || 
       (targetViewId === 'admin-view' && t.getAttribute("data-target") === 'admin-view') || 
       (targetViewId === 'login-view' && t.getAttribute("data-target") === 'admin-view')) {
      t.classList.add("active");
    } else {
      t.classList.remove("active");
    }
  });

  // Manage active class on section views
  views.forEach(v => {
    v.classList.remove("active");
  });

  if (targetViewId === "admin-view") {
    // Check authentication
    const isAuthenticated = checkAdminAuthenticated();
    if (isAuthenticated) {
      document.getElementById("admin-view").classList.add("active");
      renderRegistry();
    } else {
      document.getElementById("login-view").classList.add("active");
    }
  } else {
    document.getElementById(targetViewId).classList.add("active");
  }

  // Recalculate icons if dynamically updated
  safeCreateIcons();
}

// MODULE 1: Admin Certificate Form & Live Preview bindings
function setupFormBindings() {
  const form = document.getElementById("cert-generator-form");
  const inputRecipient = document.getElementById("input-recipient");
  const inputType = document.getElementById("input-type");
  const inputEvent = document.getElementById("input-event");
  const inputRole = document.getElementById("input-role");
  const inputDate = document.getElementById("input-date");
  
  // Set default date to today
  const today = new Date().toISOString().split('T')[0];
  inputDate.value = today;

  // Render elements in preview pane
  const previewRecipient = document.getElementById("cert-render-recipient");
  const previewType = document.getElementById("cert-render-type");
  const previewEvent = document.getElementById("cert-render-event");
  const previewDesc = document.getElementById("cert-render-desc");
  const previewId = document.getElementById("cert-render-id");
  const previewDate = document.getElementById("cert-render-date");

  // Handler to refresh preview elements
  function updatePreview() {
    const recipient = inputRecipient.value.trim() || "Eleanor Vance";
    const type = inputType.value;
    const eventName = inputEvent.value.trim() || "Borderless Poetics Workshop 2026";
    const role = inputRole.value.trim() || "Featured Literary Artist";
    const dateVal = inputDate.value || today;

    // Generate preview Serial ID
    const year = getYearFromDate(dateVal);
    const typeCode = getTypeCode(type);
    const mockSerial = getNextSerialString(year, typeCode);
    const calculatedId = `TOOP-${year}-${typeCode}-${mockSerial}`;
    
    // Update live form preview display
    document.getElementById("input-serial-preview").value = calculatedId;

    // Update canvas display
    previewRecipient.textContent = recipient;
    previewType.textContent = `Certificate of ${type}`;
    previewEvent.textContent = eventName;
    previewDate.textContent = dateVal;
    previewId.textContent = calculatedId;
    
    // Custom description details based on certificate type
    if (type === "Participation") {
      previewDesc.innerHTML = `for active and dedicated participation as a <strong>${role}</strong> in the <span id="cert-render-event">${eventName}</span> program.`;
    } else if (type === "Achievement") {
      previewDesc.innerHTML = `for outstanding accomplishments and excellence achieved as the <strong>${role}</strong> in the <span id="cert-render-event">${eventName}</span> competition.`;
    } else if (type === "Appreciation") {
      previewDesc.innerHTML = `with sincere gratitude for invaluable contributions and service as a <strong>${role}</strong> in the <span id="cert-render-event">${eventName}</span> initiative.`;
    } else {
      previewDesc.innerHTML = `in high esteem and recognition of exemplary leadership and performance as a <strong>${role}</strong> in the <span id="cert-render-event">${eventName}</span> project.`;
    }

    // Refresh dynamic verification QR Code preview
    generateQRCode(calculatedId);
  }

  // Bind input listeners
  inputRecipient.addEventListener("input", updatePreview);
  inputType.addEventListener("change", updatePreview);
  inputEvent.addEventListener("input", updatePreview);
  inputRole.addEventListener("input", updatePreview);
  inputDate.addEventListener("input", updatePreview);

  // Initial call to set defaults
  updatePreview();

  // Reset handler
  document.getElementById("btn-reset-form").addEventListener("click", () => {
    form.reset();
    inputDate.value = today;
    updatePreview();
    document.getElementById("generator-error-msg").style.display = "none";
  });

  // Submission handler (Issue & Save)
  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const recipient = inputRecipient.value.trim();
    const type = inputType.value;
    const eventName = inputEvent.value.trim();
    const role = inputRole.value.trim();
    const dateVal = inputDate.value;

    if (!recipient || !type || !eventName || !role || !dateVal) {
      document.getElementById("generator-error-msg").style.display = "block";
      return;
    }
    document.getElementById("generator-error-msg").style.display = "none";

    const year = getYearFromDate(dateVal);
    const typeCode = getTypeCode(type);
    
    // Assign definitive non-conflicting unique serial ID
    let finalId;
    let isUnique = false;
    let attempt = 0;
    while (!isUnique) {
      const currentSerial = getNextSerialString(year, typeCode, attempt);
      finalId = `TOOP-${year}-${typeCode}-${currentSerial}`;
      if (!certificates.some(c => c.id.toUpperCase() === finalId.toUpperCase())) {
        isUnique = true;
      }
      attempt++;
    }

    // Append record
    const newCert = {
      id: finalId,
      recipient,
      type,
      event: eventName,
      role,
      date: dateVal,
      status: "Active"
    };

    certificates.push(newCert);
    saveData();
    renderRegistry();
    
    alert(`Certificate successfully generated!\nCertificate ID: ${finalId}`);

    // Clean form and reset
    form.reset();
    inputDate.value = today;
    updatePreview();
  });

  // Action button: Print Preview
  document.getElementById("btn-print-preview").addEventListener("click", () => {
    window.print();
  });
}

// Convert certificate type to short uppercase code
function getTypeCode(type) {
  switch (type) {
    case "Participation": return "PART";
    case "Achievement": return "ACHV";
    case "Appreciation": return "APPR";
    case "Recognition": return "RECG";
    default: return "CERT";
  }
}

// Find next sequential serial digits for combination
function getNextSerialString(year, typeCode, offset = 0) {
  const filtered = certificates.filter(c => {
    if (!c || !c.id) return false;
    const parts = c.id.split("-");
    if (parts.length < 4) return false;
    return parts[1] === year && parts[2] === typeCode;
  });

  let maxSerialNum = 0;
  filtered.forEach(c => {
    if (!c || !c.id) return;
    const parts = c.id.split("-");
    const num = parseInt(parts[3], 10);
    if (!isNaN(num) && num > maxSerialNum) {
      maxSerialNum = num;
    }
  });

  const nextNum = maxSerialNum + 1 + offset;
  return String(nextNum).padStart(4, '0');
}

// Generate Verification QR Code using QRious library
function generateQRCode(certificateId) {
  const canvas = document.getElementById("cert-render-qr");
  if (!canvas) return;

  const verificationUrl = `${window.location.origin}${window.location.pathname}?verify=${encodeURIComponent(certificateId)}`;
  
  try {
    if (typeof QRious !== 'undefined') {
      new QRious({
        element: canvas,
        value: verificationUrl,
        size: 100,
        foreground: "#201B16", // match brand ink color
        background: "#FBF7EF"  // match warm paper tone
      });
    } else {
      // Offline fallback: draw a clean placeholder on the canvas
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.fillStyle = "#FBF7EF";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.strokeStyle = "#B8974B";
        ctx.strokeRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = "#201B16";
        ctx.font = "bold 10px Sora, sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText("Offline", canvas.width / 2, canvas.height / 2 - 5);
        ctx.font = "8px Sora, sans-serif";
        ctx.fillText("QR Code", canvas.width / 2, canvas.height / 2 + 5);
      }
    }
  } catch (e) {
    console.warn("QR code generation failed", e);
  }
}

// MODULE 2: Public Verification Portal
function setupVerificationPortal() {
  const searchInput = document.getElementById("verify-id-input");
  const searchBtn = document.getElementById("btn-verify-search");
  const resultsContainer = document.getElementById("verify-results");
  const errorMsg = document.getElementById("verify-error-msg");

  searchBtn.addEventListener("click", () => {
    const rawVal = searchInput.value.trim();
    if (!rawVal) {
      errorMsg.style.display = "block";
      errorMsg.textContent = "Please enter a Certificate ID.";
      resultsContainer.style.display = "none";
      return;
    }
    errorMsg.style.display = "none";
    verifyCertificate(rawVal);
  });

  searchInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      searchBtn.click();
    }
  });

  // Verify Print Action
  document.getElementById("btn-print-verified").addEventListener("click", () => {
    const certId = document.getElementById("result-cert-id").textContent;
    const cert = certificates.find(c => c.id.toUpperCase() === certId.toUpperCase());
    if (cert) {
      preparePreviewPane(cert);
      window.print();
    }
  });
}

// Perform Verification Search & Status Badging
function verifyCertificate(id) {
  const resultsContainer = document.getElementById("verify-results");
  const recName = document.getElementById("result-recipient-name");
  const recType = document.getElementById("result-cert-type");
  const recEvent = document.getElementById("result-event-program");
  const recRole = document.getElementById("result-role");
  const recDate = document.getElementById("result-issue-date");
  const recId = document.getElementById("result-cert-id");

  const badgeHeader = document.getElementById("result-header-badge");
  const badgeTitle = document.getElementById("result-status-title");
  const badgeDesc = document.getElementById("result-status-desc");
  const detailsGrid = document.getElementById("result-details-grid");
  const actionsBlock = document.getElementById("result-actions-block");

  // Exact lookups
  const record = certificates.find(c => c.id.trim().toUpperCase() === id.trim().toUpperCase());

  resultsContainer.style.display = "block";
  resultsContainer.scrollIntoView({ behavior: 'smooth' });

  // Clear previous theme configurations
  badgeHeader.className = "result-badge";

  if (!record) {
    // INVALID STATE
    badgeHeader.classList.add("result-invalid");
    badgeTitle.textContent = "INVALID CERTIFICATE";
    badgeDesc.textContent = "No verified record found with this ID.";
    detailsGrid.style.display = "none";
    actionsBlock.style.display = "none";
    
    // Clear elements
    recName.textContent = "-";
    recType.textContent = "-";
    recEvent.textContent = "-";
    recRole.textContent = "-";
    recDate.textContent = "-";
    recId.textContent = "-";
    return;
  }

  // Populate data
  recName.textContent = record.recipient;
  recType.textContent = record.type;
  recEvent.textContent = record.event;
  recRole.textContent = record.role;
  recDate.textContent = record.date;
  recId.textContent = record.id;
  detailsGrid.style.display = "grid";
  actionsBlock.style.display = "flex";

  if (record.status === "Active") {
    // VALID ACTIVE STATE
    badgeHeader.classList.add("result-valid");
    badgeTitle.textContent = "VALID CERTIFICATE";
    badgeDesc.textContent = "Verified Active in TOOP Registry Database";
  } else {
    // REVOKED STATE
    badgeHeader.classList.add("result-revoked");
    badgeTitle.textContent = "REVOKED CERTIFICATE";
    badgeDesc.textContent = "This credential was officially revoked by TOOP Administration.";
  }
}

// Setup Admin Authentication Gating
function setupAdminPortal() {
  const form = document.getElementById("admin-login-form");
  const passcodeField = document.getElementById("gate-passcode-input");
  const submitBtn = document.getElementById("btn-submit-passcode");
  const errorMsg = document.getElementById("gate-error-msg");
  const logoutBtn = document.getElementById("btn-admin-logout");

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const code = passcodeField.value.trim();
    if (code.toUpperCase() === "TOOP2026") {
      setAdminAuthenticated(true);
      errorMsg.style.display = "none";
      passcodeField.value = "";
      switchTab("admin-view");
    } else {
      errorMsg.style.display = "block";
    }
  });

  logoutBtn.addEventListener("click", () => {
    logoutAdmin();
    switchTab("admin-view"); // Will redirect to login view
  });
}

// MODULE 3: Registry Dashboard Table & Controls
function renderRegistry() {
  const tbody = document.getElementById("registry-table-body");
  const emptyState = document.getElementById("registry-empty-state");
  const table = document.getElementById("registry-table");
  const countBadge = document.getElementById("registry-count-badge");

  const searchInput = document.getElementById("registry-search-input").value.trim().toLowerCase();
  const filterStatus = document.getElementById("registry-filter-status").value;
  const filterType = document.getElementById("registry-filter-type").value;

  tbody.innerHTML = "";

  // Apply search filtering
  const filtered = certificates.filter(c => {
    const matchesSearch = c.recipient.toLowerCase().includes(searchInput) || c.id.toLowerCase().includes(searchInput);
    const matchesStatus = filterStatus === "all" || c.status === filterStatus;
    const matchesType = filterType === "all" || c.type === filterType;
    return matchesSearch && matchesStatus && matchesType;
  });

  countBadge.textContent = filtered.length;

  if (filtered.length === 0) {
    emptyState.style.display = "block";
    table.style.display = "none";
    return;
  }

  emptyState.style.display = "none";
  table.style.display = "table";

  filtered.forEach(c => {
    const tr = document.createElement("tr");

    // Columns
    const tdId = document.createElement("td");
    tdId.style.fontFamily = "monospace";
    tdId.style.fontWeight = "700";
    tdId.textContent = c.id;

    const tdRecipient = document.createElement("td");
    tdRecipient.style.fontWeight = "600";
    tdRecipient.textContent = c.recipient;

    const tdType = document.createElement("td");
    tdType.textContent = c.type;

    const tdEvent = document.createElement("td");
    tdEvent.textContent = c.event;

    const tdDate = document.createElement("td");
    tdDate.textContent = c.date;

    const tdStatus = document.createElement("td");
    const badge = document.createElement("span");
    badge.className = `badge ${c.status === "Active" ? "badge-active" : "badge-revoked"}`;
    badge.innerHTML = c.status === "Active" ? '<i data-lucide="shield-check" style="width: 12px; height: 12px;"></i> Active' : '<i data-lucide="shield-alert" style="width: 12px; height: 12px;"></i> Revoked';
    tdStatus.appendChild(badge);

    const tdActions = document.createElement("td");

    // Action: Status toggle (Active <-> Revoked)
    const btnToggle = document.createElement("button");
    btnToggle.className = "btn-icon";
    btnToggle.title = c.status === "Active" ? "Revoke Certificate" : "Activate Certificate";
    btnToggle.innerHTML = c.status === "Active" ? '<i data-lucide="user-minus"></i>' : '<i data-lucide="user-check"></i>';
    btnToggle.addEventListener("click", () => {
      c.status = c.status === "Active" ? "Revoked" : "Active";
      saveData();
      renderRegistry();
    });

    // Action: Load into preview & print
    const btnPrint = document.createElement("button");
    btnPrint.className = "btn-icon";
    btnPrint.title = "Print Certificate";
    btnPrint.innerHTML = '<i data-lucide="printer"></i>';
    btnPrint.addEventListener("click", () => {
      preparePreviewPane(c);
      setTimeout(() => {
        window.print();
      }, 100);
    });

    // Action: Delete record
    const btnDelete = document.createElement("button");
    btnDelete.className = "btn-icon btn-icon-danger";
    btnDelete.title = "Delete Certificate";
    btnDelete.innerHTML = '<i data-lucide="trash-2"></i>';
    btnDelete.addEventListener("click", () => {
      if (confirm(`Are you sure you want to delete certificate record ${c.id} for ${c.recipient}? This action cannot be undone.`)) {
        certificates = certificates.filter(item => item.id !== c.id);
        saveData();
        renderRegistry();
      }
    });

    const actionsWrapper = document.createElement("div");
    actionsWrapper.className = "action-buttons";
    actionsWrapper.appendChild(btnToggle);
    actionsWrapper.appendChild(btnPrint);
    actionsWrapper.appendChild(btnDelete);
    tdActions.appendChild(actionsWrapper);

    tr.appendChild(tdId);
    tr.appendChild(tdRecipient);
    tr.appendChild(tdType);
    tr.appendChild(tdEvent);
    tr.appendChild(tdDate);
    tr.appendChild(tdStatus);
    tr.appendChild(tdActions);

    tbody.appendChild(tr);
  });

  // Re-render Lucide icons inside dynamically created elements
  safeCreateIcons();
}

// Load a specific certificate object details into the preview pane
function preparePreviewPane(cert) {
  document.getElementById("cert-render-recipient").textContent = cert.recipient;
  document.getElementById("cert-render-type").textContent = `Certificate of ${cert.type}`;
  document.getElementById("cert-render-event").textContent = cert.event;
  document.getElementById("cert-render-date").textContent = cert.date;
  document.getElementById("cert-render-id").textContent = cert.id;

  const desc = document.getElementById("cert-render-desc");
  if (cert.type === "Participation") {
    desc.innerHTML = `for active and dedicated participation as a <strong>${cert.role}</strong> in the <span id="cert-render-event">${cert.event}</span> program.`;
  } else if (cert.type === "Achievement") {
    desc.innerHTML = `for outstanding accomplishments and excellence achieved as the <strong>${cert.role}</strong> in the <span id="cert-render-event">${cert.event}</span> competition.`;
  } else if (cert.type === "Appreciation") {
    desc.innerHTML = `with sincere gratitude for invaluable contributions and service as a <strong>${cert.role}</strong> in the <span id="cert-render-event">${cert.event}</span> initiative.`;
  } else {
    desc.innerHTML = `in high esteem and recognition of exemplary leadership and performance as a <strong>${cert.role}</strong> in the <span id="cert-render-event">${cert.event}</span> project.`;
  }

  generateQRCode(cert.id);
}

// Bind event listeners for registry search and filtering
function setupAdminPortalControls() {
  const searchInput = document.getElementById("registry-search-input");
  const filterStatus = document.getElementById("registry-filter-status");
  const filterType = document.getElementById("registry-filter-type");

  searchInput.addEventListener("input", renderRegistry);
  filterStatus.addEventListener("change", renderRegistry);
  filterType.addEventListener("change", renderRegistry);
}

// MODULE 3: CSV Import & Export Tools
function setupCSVTools() {
  // Export CSV
  document.getElementById("btn-export-csv").addEventListener("click", () => {
    if (certificates.length === 0) {
      alert("No records to export.");
      return;
    }

    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Certificate ID,Recipient Name,Certificate Type,Event / Program,Role / Achievement,Issue Date,Status\n";

    certificates.forEach(c => {
      // Escape commas and double quotes for clean CSV writing
      const id = `"${c.id.replace(/"/g, '""')}"`;
      const recipient = `"${c.recipient.replace(/"/g, '""')}"`;
      const type = `"${c.type.replace(/"/g, '""')}"`;
      const event = `"${c.event.replace(/"/g, '""')}"`;
      const role = `"${c.role.replace(/"/g, '""')}"`;
      const date = `"${c.date.replace(/"/g, '""')}"`;
      const status = `"${c.status.replace(/"/g, '""')}"`;

      csvContent += `${id},${recipient},${type},${event},${role},${date},${status}\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `toop-certificates-export-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  });

  // Modal Open/Close Elements
  const modal = document.getElementById("csv-import-modal");
  const dropZone = document.getElementById("csv-drop-zone");
  const fileInput = document.getElementById("csv-file-input");

  document.getElementById("btn-open-import").addEventListener("click", () => {
    modal.classList.add("active");
  });

  document.getElementById("btn-close-import").addEventListener("click", () => {
    modal.classList.remove("active");
  });

  window.addEventListener("click", (e) => {
    if (e.target === modal) {
      modal.classList.remove("active");
    }
  });

  // CSV Drag and Drop Event listeners
  dropZone.addEventListener("click", () => fileInput.click());

  dropZone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropZone.classList.add("dragover");
  });

  dropZone.addEventListener("dragleave", () => {
    dropZone.classList.remove("dragover");
  });

  dropZone.addEventListener("drop", (e) => {
    e.preventDefault();
    dropZone.classList.remove("dragover");
    if (e.dataTransfer.files.length > 0) {
      handleCsvFile(e.dataTransfer.files[0]);
    }
  });

  fileInput.addEventListener("change", (e) => {
    if (fileInput.files.length > 0) {
      handleCsvFile(fileInput.files[0]);
      fileInput.value = ""; // clear value for re-selection
    }
  });

  // Parse CSV records
  function handleCsvFile(file) {
    if (!file.name.endsWith(".csv")) {
      alert("Invalid file format. Please upload a .csv file.");
      return;
    }

    const reader = new FileReader();
    reader.onload = function(e) {
      const text = e.target.result;
      processCSV(text);
    };
    reader.readAsText(file);
  }

  function processCSV(text) {
    const lines = text.split(/\r?\n/);
    if (lines.length < 2) {
      alert("Empty or malformed CSV file.");
      return;
    }

    // Simple CSV parser supporting quotes
    function parseCSVLine(line) {
      const result = [];
      let current = '';
      let inQuotes = false;
      for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"') {
          inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
          result.push(current.trim());
          current = '';
        } else {
          current += char;
        }
      }
      result.push(current.trim());
      return result;
    }

    const headers = parseCSVLine(lines[0]);
    
    // Normalize headers
    const colIndex = {
      id: headers.findIndex(h => h.toLowerCase().includes("id")),
      recipient: headers.findIndex(h => h.toLowerCase().includes("recipient") || h.toLowerCase().includes("name")),
      type: headers.findIndex(h => h.toLowerCase().includes("type")),
      event: headers.findIndex(h => h.toLowerCase().includes("event") || h.toLowerCase().includes("program")),
      role: headers.findIndex(h => h.toLowerCase().includes("role") || h.toLowerCase().includes("achievement")),
      date: headers.findIndex(h => h.toLowerCase().includes("date")),
      status: headers.findIndex(h => h.toLowerCase().includes("status"))
    };

    if (colIndex.recipient === -1 || colIndex.type === -1 || colIndex.event === -1 || colIndex.role === -1 || colIndex.date === -1) {
      alert("Error parsing CSV: Missing required columns. Ensure columns exist for: Recipient Name, Certificate Type, Event / Program, Role / Achievement, Issue Date.");
      return;
    }

    let importCount = 0;
    let duplicateCount = 0;
    let errorCount = 0;

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;

      const cols = parseCSVLine(line);
      if (cols.length < 5) {
        errorCount++;
        continue;
      }

      const recipient = cols[colIndex.recipient];
      const type = cols[colIndex.type];
      const eventName = cols[colIndex.event];
      const role = cols[colIndex.role];
      const dateVal = cols[colIndex.date];
      
      // Parse optional fields
      let status = "Active";
      if (colIndex.status !== -1 && cols[colIndex.status]) {
        const inputStatus = cols[colIndex.status].toLowerCase();
        if (inputStatus.includes("revok")) {
          status = "Revoked";
        }
      }

      // Check for valid certificate type values
      const validTypes = ["Participation", "Achievement", "Appreciation", "Recognition"];
      const matchedType = validTypes.find(t => t.toLowerCase() === type.toLowerCase());

      if (!recipient || !matchedType || !eventName || !role || !dateVal) {
        errorCount++;
        continue;
      }

      // Check ID. If custom ID exists in CSV, check duplication. Else generate.
      let id = "";
      if (colIndex.id !== -1 && cols[colIndex.id]) {
        id = cols[colIndex.id].trim();
      }

      if (id && certificates.some(c => c.id.toUpperCase() === id.toUpperCase())) {
        duplicateCount++;
        continue;
      }

      if (!id) {
        // Generate new unique ID
        const year = getYearFromDate(dateVal);
        const typeCode = getTypeCode(matchedType);
        
        let finalId;
        let isUnique = false;
        let attempt = 0;
        while (!isUnique) {
          const currentSerial = getNextSerialString(year, typeCode, attempt);
          finalId = `TOOP-${year}-${typeCode}-${currentSerial}`;
          if (!certificates.some(c => c.id.toUpperCase() === finalId.toUpperCase())) {
            isUnique = true;
          }
          attempt++;
        }
        id = finalId;
      }

      certificates.push({
        id,
        recipient,
        type: matchedType,
        event: eventName,
        role,
        date: dateVal,
        status
      });
      importCount++;
    }

    saveData();
    renderRegistry();
    modal.classList.remove("active");
    
    alert(`CSV Import Finished!\n- Successfully imported: ${importCount} records\n- Skipped duplicates: ${duplicateCount}\n- Skipped errors/invalid: ${errorCount}`);
  }
}

// Check for direct URL parameter routing (e.g. from scanning a QR code)
function checkUrlParams() {
  const urlParams = new URLSearchParams(window.location.search);
  const verifyId = urlParams.get('verify');
  if (verifyId) {
    // Switch to verification view immediately
    switchTab("verify-view");
    document.getElementById("verify-id-input").value = verifyId;
    verifyCertificate(verifyId);
  }
}

// Initial binding helper for searching registry filters
setupAdminPortalControls();

// Collapsible Bulk Text Area Importer (Name | Event | Type | Role | Date)
function setupBulkTextAreaImport() {
  const toggleBtn = document.getElementById("btn-toggle-bulk");
  const container = document.getElementById("bulk-import-container");
  const submitBtn = document.getElementById("btn-submit-bulk");
  const textarea = document.getElementById("bulk-import-textarea");

  if (!toggleBtn || !container || !submitBtn || !textarea) return;

  toggleBtn.addEventListener("click", () => {
    const isHidden = container.style.display === "none";
    if (isHidden) {
      container.style.display = "block";
      toggleBtn.textContent = "Hide Bulk Import";
    } else {
      container.style.display = "none";
      toggleBtn.textContent = "Show Bulk Import";
    }
  });

  submitBtn.addEventListener("click", () => {
    const text = textarea.value.trim();
    if (!text) {
      alert("Please enter at least one record in the textarea.");
      return;
    }

    const lines = text.split("\n");
    let importCount = 0;
    let skipCount = 0;

    const today = new Date().toISOString().split('T')[0];

    lines.forEach(line => {
      const trimmedLine = line.trim();
      if (!trimmedLine) return; // skip empty lines

      const parts = trimmedLine.split("|").map(p => p.trim());
      const recipient = parts[0];
      const eventName = parts[1];
      
      if (!recipient || !eventName) {
        skipCount++;
        return; // skip if required fields are missing
      }

      // Optional fields
      let type = "Participation";
      if (parts[2]) {
        const validTypes = ["Participation", "Achievement", "Appreciation", "Recognition"];
        const matchedType = validTypes.find(t => t.toLowerCase() === parts[2].toLowerCase());
        if (matchedType) type = matchedType;
      }

      const role = parts[3] || "Participant";
      const dateVal = parts[4] || today;

      const year = getYearFromDate(dateVal);
      const typeCode = getTypeCode(type);

      // Generate unique ID
      let finalId;
      let isUnique = false;
      let attempt = 0;
      while (!isUnique) {
        const currentSerial = getNextSerialString(year, typeCode, attempt);
        finalId = `TOOP-${year}-${typeCode}-${currentSerial}`;
        if (!certificates.some(c => c.id.toUpperCase() === finalId.toUpperCase())) {
          isUnique = true;
        }
        attempt++;
      }

      // Add to array
      certificates.push({
        id: finalId,
        recipient,
        type,
        event: eventName,
        role,
        date: dateVal,
        status: "Active"
      });
      importCount++;
    });

    if (importCount > 0) {
      saveData();
      renderRegistry();
      textarea.value = "";
      alert(`Bulk issuance complete!\n- Successfully generated: ${importCount} certificates\n- Skipped invalid lines: ${skipCount}`);
    } else {
      alert(`No certificates were generated. Skipped: ${skipCount} lines. Please check your format.`);
    }
  });
}
