# TOOP — Certificate Generator & Verification Portal

A complete, judging-ready certificate management ecosystem built for **TOOP — The Order of Pen**. It allows coordinators to instantly generate, preview, save, search, and revoke digital credentials.

## 0. Branding & Identity

- **Org Tagline:** *"Celebrating Art and Literature Across Borders"*
- **Motto:** *"Ars Longa, Vita Brevis"* (Art is long, life is short)
- **Palette:**
  - Primary Brand Red: `#CC3327` (Sampled from the official seal logo)
  - Hover/Dark State Red: `#A32A20`
  - Body Ink: `#201B16` (Warm near-black)
  - Primary Paper Canvas: `#FBF7EF`
  - Card Secondary Background: `#F1E7D4`
  - Seal/Accent Gold: `#B8974B`
- **Typography:**
  - Headings/App UI: `Sora` (Bold, tight, geometric sans-serif)
  - Certificate: `Fraunces` (Elegant, literary, high-contrast serif)

---

## 1. Technologies Used

- **HTML5 & Vanilla CSS3** — Fully customized layout structure, responsive flexbox/grid layout, and print media rules.
- **Vanilla JavaScript (ES6)** — Dynamic view routing, form validation, and reactive canvas previews.
- **localStorage & sessionStorage** — Client-side persistent databases for certificates and admin session states.
- **Lucide Icons (via CDN)** — Modern vector icons.
- **QRious JS (via CDN)** — Clean QR code rendering on canvas elements.

---

## 2. Installation & How to Run

1. Clone or extract the project files into a directory.
2. Double-click the [index.html](file:///c:/Users/rajaa/TOOP_Website/index.html) file to open it directly in any modern browser (Chrome, Edge, Firefox, Safari).
   - *Alternatively*, run a local dev server (e.g. `npx serve .` or Live Server in VS Code) for URL-routing integrations.
3. Keep console developer tools open if you want to inspect performance.

---

## 3. Features Summary

### Completed Core Features (100% Fully Functional)
- **Certificate Generation Form** — Captures recipient name, type, program, role, and date with validation.
- **Unique ID Generation Pattern** — Assigns a strict sequential template code based on year and category (e.g. `TOOP-2026-APPR-0001`) preventing duplication.
- **Live Preview Canvas** — Immediate re-rendering of fonts, layout borders, details, and signatures as values are entered.
- **Data Persistence** — Direct write-to/read-from `localStorage` keeping records intact after browser reloads.
- **Registry Table & Controls** — List view of records with name/ID search filters and active certificate counters.
- **Public Verification Search** — Exact match validation yielding distinctly designed UI cards for Valid (Active), Invalid (Not Found), and Revoked credentials.
- **Administrative Access Controls** — Simple toggle switches to swap certificate status from `Active` to `Revoked` instantly.
- **Seeded Sample Data** — 3 ready-to-test credentials containing valid and revoked states loaded on first load.

### Completed Bonus Features
- **Dynamic QR Code Verification (Bonus 1)** — Auto-renders a custom QR code on the certificate. Scanning the QR code (or opening the encoded URL parameter e.g., `?verify=TOOP-2026-APPR-0001`) redirects visitors to the portal and performs instant verification automatically.
- **Batch CSV Import (Bonus 2)** — Drag-and-drop or select a `.csv` data sheet to issue multiple certificates simultaneously with automated field matching and duplicate verification.
- **CSV Data Export (Bonus 4)** — One-click download compiling all registry records into a `.csv` format spreadsheet.
- **Print / Save as PDF Stylesheets** — Action triggers isolate the certificate canvas and format it for landscape A4 output.
- **Admin passcode gate (Bonus 7)** — Secures critical generator forms and status controls with client-side passcode authentication (**`TOOP2026`**).
- **Polished UX & Micro-animations (Bonus 8)** — Soft slide-down transitions, lock icons, seal badges, empty states, and dynamic status symbols.

### Incomplete Features
- *None. All core constraints and major bonus options are fully implemented.*

---

## 4. User Passcode Gate
- **Passcode:** `TOOP2026` (Use this code in the Admin Portal tab to unlock generator forms, registry tables, status controls, and CSV tools).
